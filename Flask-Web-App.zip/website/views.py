from re import template
from aiohttp import ClientSession
from flask import Blueprint, render_template, request, flash, jsonify, session, send_file, url_for, redirect
from flask_login import login_required, current_user
from .models import Note
from .models import UploadedFiles
from . import db
import json
import pandas as pd
from tablib import Dataset
import os
import base64
import numpy as np
import xml.etree.ElementTree as ET
import urllib
import urllib.request
from urllib.request import Request, urlopen
import requests
import asyncio
import aiohttp
import time
import io

views = Blueprint('views', __name__)


@views.route('/', methods=['GET', 'POST'])
@login_required
def home():
    # if request.method == 'POST':
    #   note = request.form.get('note')
    #
    #  if len(note) < 1:
 #           flash('Note is too short!', category='error')
  #      else:
   #         new_note = Note(data=note, user_id=current_user.id)
    #        db.session.add(new_note)
    #       db.session.commit()
    #      flash('Note added!', category='success')

    return render_template("home.html", user=current_user)


# File Uploader
APP_ROOT = os.path.dirname(os.path.abspath(__file__))


var_list = []

a=None
@login_required
@views.route('/upload', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
        file = request.files['file']
        df = pd.read_excel(file)
        if not os.path.isdir('Uploaded Files'):
            os.mkdir('Uploaded Files')
        filepath = os.path.join('Uploaded Files', file.filename)
        file.save(filepath)
        # newFile = UploadedFiles(name=file.filename, data=file.read())
        # db.session.add(newFile)
        # db.session.commit()

        # df = pd.read_excel(file)
        
        # data = df.to_msgpack()
        # session['data'] = data
        # dfstr = pd.read_json(d)
        # df1 = pd.DataFrame(dfstr)
        df1=df
        # print('this is dataframe from upload')
        # print(df1)
        # Checking the length to get unusal datas dropped
        df = df1[df1['Number'].map(lambda x: len(str(x)) == 13)]
        # numbers to numeric
        df["Number"] = pd.to_numeric(df["Number"], errors='coerce')
        # Drop nulls from Numbers
        df = df.dropna(subset=['Number'])
        df = df.dropna()
        df['Number'] = df['Number'].astype('int64')
        # Store Dropped Data
        dfG = df1[~df1.index.isin(df.index)]
        # data = df
        data = df.head(10)
        # print(data)
        # # URLS Encoding
        # import urllib.parse
        # df['Text'] = df['Text'].apply(urllib.parse.quote)

        global a
        a=df

        # session["dfmain"] = splitdf.to_json()
        return render_template("home.html", user=current_user, data=data.to_html())


#######Campaign Start#######
loop = asyncio.new_event_loop()
asyncio.set_event_loop(loop)

# maindf = []

b=None
user_name = None
user_pass = None

@login_required
@views.route('/campaign', methods=['GET', 'POST'])
def camapign():
    # d = session.get('dataframe')
    # df1 = pd.read_mesgpack(session['data'])
    # sdf = session.get('dataframe')
    # dfn = pd.read_json(sdf)
    # df = pd.DataFrame(dfn)
    df=a
    # print("This is uploaded file from upload function")
    # print(df)
    # URLS Encoding
    import urllib.parse
    df['Text'] = df['Text'].apply(urllib.parse.quote)

    
    ##### URL LIST #####
    urls = []
    global user_name,user_pass
    user_name = request.form.get('masking_name')
    user_pass = request.form.get('masking_pass')
    user_mask = request.form.get('masking')
    
    # session['user_mask'] = [user_mask]
    # print(df)
    for index, row in df.iterrows():
        N = row['Number']
        T = row['Text']
        url = (
            f"https://api.mobireach.com.bd/SendTextMessage?Username={user_name}&Password={user_pass}&From={user_mask}&To={N}&Message={T}")
        urls.append(url)
    # print('This is urls list')
    # print(urls)
    import time
    start_time = time.time()

    import asyncio
    import aiohttp
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    from aiohttp import ClientSession
    
    maindf = []

    async def hello(url, sema):
        async with ClientSession(trust_env=True) as session:
            #   maindf= []
            async with sema, session.get(url) as response:
                response = await response.read()
                # print('Response here NNNNNNNNNNNN')
                # print(response)
                root = ET.XML(response)  # Parse XML
                data = []
                for i, child in enumerate(root):
                    data.append([subchild.text for subchild in child])
                maindf.append(data)

    async def main():
        async with aiohttp.ClientSession(trust_env=True) as session:
            sema = asyncio.BoundedSemaphore(200)
            tasks = [hello(url, sema) for url in urls]
            await asyncio.gather(*tasks)

    asyncio.run(main())
    # policy = asyncio.WindowsSelectorEventLoopPolicy()
    # asyncio.set_event_loop_policy(policy)
    
    maindf = pd.DataFrame(maindf)
    # print('This is maindf')
    # print(maindf)
    maindf.rename(columns={0: 'Report'}, inplace=True)
    splitdf = maindf.Report.apply(lambda x: pd.Series(str(x).split(",")))
    splitdf.rename(columns={0: 'MessageId', 1: 'Status', 2: 'StatusText', 3: 'ErrorCode', 4: 'ErrorText', 5: 'SMSCount', 6: 'CurrentCredit'}, inplace=True)
    splitdf['MessageId'] = splitdf['MessageId'].str.replace('[', '')
    splitdf['MessageId'] = splitdf['MessageId'].str.replace("'", '')
    # session["dfmain"] = splitdf.to_json()
    data = splitdf.head(10)
    global b
    b = splitdf
    #### Campaign Report ####
    flash('Campaign Completed! Generating Campaign Report', category='success')
    ##### URL LIST #####
    # return redirect(url_for('views.generatereport'))
    return render_template("home.html", user=current_user, d=data.to_html())



c=None
@login_required
@views.route('/generate-report', methods=['GET', 'POST'])
def generatereport():
    # splitdf = b
    # dfsplit = pd.read_json(splitdf)
    df1 = pd.DataFrame(b)
    print("This file from campign")
    # print(df1)
    murls = []
    print('This is murls list')
    # print(murls)

    # user_name = session.get('masking_name')
    # user_pass = session.get('masking_pass')
    # print('This is the user name from the other function')
    print(user_name)
    print('Here is user name from upload function')
    for index, row in df1.iterrows():
        mid=row['MessageId']
        url = (f"https://api.mobireach.com.bd/GetMessageStatus?Username={user_name}&Password={user_pass}&MessageId={mid}")
        murls.append(url)
    # print(urls)
    
    reportdf = []

    async def report(url, sema):
        async with ClientSession(trust_env=True) as session:
            #   maindf= []
            async with sema, session.get(url) as response:
                response = await response.read()
                # print('Response here NNNNNNNNNNNN')
                # print(response)
                root = ET.XML(response)  # Parse XML
                data = []
                for i, child in enumerate(root):
                    data.append([subchild.text for subchild in child])
                reportdf.append(data)

    async def reportmain():
        async with aiohttp.ClientSession(trust_env=True) as session:
            sema = asyncio.BoundedSemaphore(200)
            tasks = [report(url, sema) for url in murls]
            await asyncio.gather(*tasks)

    asyncio.run(reportmain())
    # policy = asyncio.WindowsSelectorEventLoopPolicy()
    # asyncio.set_event_loop_policy(policy)
    # flash('Campaign Completed! Generating Campaign Report', category='success')
    reportdf = pd.DataFrame(reportdf)
    # print(maindf)
    reportdf.rename(columns={0: 'Report'}, inplace=True)
    reportsplitdf = reportdf.Report.apply(lambda x: pd.Series(str(x).split(",")))
    reportsplitdf.rename(columns={0: 'MessageId', 1: 'Status', 2: 'StatusText', 3: 'ErrorCode', 4: 'ErrorText', 5: 'SMSCount', 6: 'CurrentCredit'}, inplace=True)
    reportsplitdf['MessageId'] = reportsplitdf['MessageId'].str.replace('[', '')
    reportsplitdf['MessageId'] = reportsplitdf['MessageId'].str.replace("'", '')
    data= reportsplitdf.head(10)
    global c
    c = reportsplitdf.to_csv(index=False, header=True, sep=";")
    return render_template("home.html", user=current_user, du=data.to_html())









@login_required
@views.route('/download-report', methods=['GET', 'POST'])
def downloadreport():
    # csv = session["reportsplitdf"] if "reportsplitdf" in session else ""
    csv = c
    # Create a string buffer
    buf_str = io.StringIO(csv)

    # Create a bytes buffer from the string buffer
    buf_byt = io.BytesIO(buf_str.read().encode("utf-8"))
    
    # Return the CSV data as an attachment
    return send_file(buf_byt,
                     mimetype="text/csv",
                     as_attachment=True,
                     attachment_filename="Campaign_Delivery_Report.csv")







@views.route('/delete-note', methods=['POST'])
def delete_note():
    note = json.loads(request.data)
    noteId = note['noteId']
    note = Note.query.get(noteId)
    if note:
        if note.user_id == current_user.id:
            db.session.delete(note)
            db.session.commit()

    return jsonify({})


# urls.clear()



########## template Message Starts Here #########



@login_required
@views.route('/template-Message', methods=['GET', 'POST'])
def templateMessage():
    if request.method == 'POST':
        # global user_name,user_pass,user_number
        user_name = request.form.get('masking_name')
        user_pass = request.form.get('masking_pass')
        user_mask = request.form.get('masking')
        user_number = request.form.to_dict('number')
        # file = request.files['file']
        df = pd.DataFrame(user_number, index=[0])
        new_df = pd.DataFrame(df.number.str.split(',').tolist()).stack()
        new_df = new_df.reset_index([0])
        new_df.rename(columns={0: 'Number'}, inplace=True)
        new_df = new_df['Number']
        df=pd.DataFrame(new_df)
        
        # df2 = user_number.decode('utf8')
        # buf_str = io.StringIO(df)
        # file = io.BytesIO(buf_str.read().encode("utf-8"))
        # if not os.path.isdir('Uploaded Files'):
        #     os.mkdir('Uploaded Files')
        # filepath = os.path.join('Uploaded Files')
        # file.save(filepath)
        
        
        return render_template("home.html", user=current_user, dc=df.to_html())
        df = df1[df1['Number'].map(lambda x: len(str(x)) == 13)]
        # numbers to numeric
        df["Number"] = pd.to_numeric(df["Number"], errors='coerce')
        df = df.dropna(subset=['Number'])
        df = df.dropna()
        df['Number'] = df['Number'].astype('int64')
        dfG = df1[~df1.index.isin(df.index)]
        

        # global a
        # a=df
