from flask import Flask 
from flask import Flask, redirect, url_for, render_template, request, flash, redirect, session, send_file
from flask import send_from_directory
from flask_sqlalchemy import SQLAlchemy 
from flask_security import Security, SQLAlchemyUserDatastore, UserMixin, RoleMixin, login_required, current_user, roles_accepted,roles_required, utils
from flask_mail import Mail 
from flask_security.forms import RegisterForm, LoginForm
from wtforms import StringField, IntegerField
from wtforms import validators
import os
from flask_admin import Admin, AdminIndexView
from flask_admin.contrib.sqla import ModelView
from flask_admin.contrib import sqla
from sqlalchemy.sql import func
import datetime
from sqlalchemy import Column, Integer, DateTime
from wtforms.fields import PasswordField
from flask_mail import Mail, Message
from itsdangerous import URLSafeTimedSerializer, SignatureExpired
from sqlalchemy.dialects.sqlite import BLOB
from io import BytesIO 
########### Custom Imports Starts ############
# from re import template
from flask import Blueprint, render_template, request, flash, jsonify, session, send_file, url_for, redirect
from aiohttp import ClientSession
import pandas as pd
import base64
import numpy as np
import xml.etree.ElementTree as ET
from urllib.request import Request, urlopen
import requests
import asyncio
import aiohttp
import json
import time
import io
import sys
########### Custom Imports Ends   ############
# import email_validator


app = Flask(__name__)
app.config['SECRET_KEY'] = 'nayeem_secret_key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///security.db'
app.config['SECURITY_REGISTERABLE'] = True
app.config['SECURITY_CONFIRMABLE'] = True
app.config['SECURITY_PASSWORD_SALT'] = 'mysalt'
app.config['SECURITY_SEND_REGISTER_EMAIL'] = True
app.config['SECURITY_RECOVERABLE'] = True
app.config['SECURITY_CHANGEABLE'] = True
app.config['SECURITY_EMAIL_SENDER'] = 'islam.nayeem@outlook.com'
app.config['SECURITY_EMAIL_SUBJECT_REGISTER'] = 'Welcome to mobiReach'
app.config['SECURITY_EMAIL_PLAINTEXT'] = True
app.config['SECURITY_EMAIL_HTML'] = False
app.config['SECURITY_FLASH_MESSAGES'] = True
app.config.from_pyfile('mail_config.cfg')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True
# APP_ROOT = os.path.dirname(os.path.abspath(__file__))
# app.config['SECURITY_LOGIN_URL']='/createuser'
db = SQLAlchemy(app)
# admin = Admin(app)
mail = Mail(app)

# pd df to db
from sqlalchemy import create_engine
import sqlite3
engine = create_engine('sqlite:///security.db', echo=True)
# conn = sqlite3.connect('sqlite:///security.db')
conn = sqlite3.connect('C:/Users/NayeemIslam/OneDrive - ADA Asia/Desktop/CurrentTest/security.db', check_same_thread=False)
cursor = None
c = conn.cursor()



# Define models
roles_users = db.Table('roles_users',
        db.Column('user_id', db.Integer(), db.ForeignKey('user.id')),
        db.Column('role_id', db.Integer(), db.ForeignKey('role.id')))

# Uploaded Files By Users
files_users = db.Table('files_users',
        db.Column('user_id', db.Integer(), db.ForeignKey('user.id')),
        db.Column('file_id', db.Integer(), db.ForeignKey('uploaded_data.id'))
        )

# Role Table
class Role(db.Model, RoleMixin):
    id = db.Column(db.Integer(), primary_key=True)
    name = db.Column(db.String(80), unique=True)
    description = db.Column(db.String(255))

    def __str__(self):
        return self.name
    def __hash__(self):
        return hash(self.name)



# User Table
class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(255), unique=True)
    password = db.Column(db.String(255))
    name = db.Column(db.String(255))
    age = db.Column(db.Integer)
    active = db.Column(db.Boolean())
    confirmed_at = db.Column(db.DateTime())
    roles = db.relationship('Role', secondary=roles_users,
                            backref=db.backref('users', lazy='dynamic'))
    campaigns = db.relationship('Uploaded_data', secondary=files_users,
                            backref=db.backref('users', lazy='dynamic'))


class Uploaded_data(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    Campaign_Name = db.Column(db.String(555))
    index = db.Column(db.Integer)
    Text = db.Column(db.String)
    Number = db.Column(db.String)
    Campaign_Time = db.Column(db.DateTime())
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)

    def __str__(self):
        return self.Campaign_Name
    


############# Customizing Admin Interface ############

# Customized Admin Index
class MyAdminIndexView(AdminIndexView):
    def is_accessible(self):
        return current_user.has_role('admin')
    def inaccessible_callback(self, name, **kwargs):
        return redirect('/login')

# Customized User model for SQL-Admin
class UserAdmin(sqla.ModelView):

    # Don't display the password on the list of Users
    column_exclude_list = ('password',)

    # Don't include the standard password field when creating or editing a User (but see below)
    form_excluded_columns = ('password',)

    # Automatically display human-readable names for the current and available Roles when creating or editing a User
    column_auto_select_related = True

    # Prevent administration of Users unless the currently logged-in user has the "admin" role
    def is_accessible(self):
        return current_user.has_role('admin')
    def inaccessible_callback(self, name, **kwargs):
        return redirect('/login')

    # On the form for creating or editing a User, don't display a field corresponding to the model's password field.
    # There are two reasons for this. First, we want to encrypt the password before storing in the database. Second,
    # we want to use a password field (with the input masked) rather than a regular text field.
    def scaffold_form(self):

        # Start with the standard form as provided by Flask-Admin. We've already told Flask-Admin to exclude the
        # password field from this form.
        form_class = super(UserAdmin, self).scaffold_form()

        # Add a password field, naming it "password2" and labeling it "New Password".
        form_class.password2 = PasswordField('New Password')
        return form_class

    # This callback executes when the user saves changes to a newly-created or edited User -- before the changes are
    # committed to the database.
    def on_model_change(self, form, model, is_created):

        # If the password field isn't blank...
        if len(model.password2):

            # ... then encrypt the new password prior to storing it in the database. If the password field is blank,
            # the existing password in the database will be retained.
            model.password = utils.encrypt_password(model.password2)


# Customized Role model for SQL-Admin
class RoleAdmin(sqla.ModelView):

    # Prevent administration of Roles unless the currently logged-in user has the "admin" role
    def is_accessible(self):
        return current_user.has_role('admin')
    def inaccessible_callback(self, name, **kwargs):
        return redirect('/login')
    
    

########### Admin Interface Customization Ends ##########



############# Add to Admin Views #########
admin = Admin(app, template_mode='bootstrap4' ,index_view=MyAdminIndexView())
admin.add_view(UserAdmin(User, db.session))
admin.add_view(RoleAdmin(Role, db.session))
admin.add_view(ModelView(Uploaded_data, db.session))

############# Admin Views End ###########

class ExtendedRegisterForm(RegisterForm):
    name = StringField('Name')
    age = IntegerField('Age')
    


######## Custom Login Form Values ########

class CustomLoginForm(LoginForm):
    password = StringField('ADA Password')

######## Custom Login Form Values Ends ########

user_datastore = SQLAlchemyUserDatastore(db, User, Role)
security = Security(app, user_datastore, register_form=ExtendedRegisterForm, login_form=CustomLoginForm)




########### Test Values For Database #########
@app.before_first_request
def before_first_request():

    # Create any database tables that don't exist yet.
    db.create_all()

    # Create the Roles "admin" and "end-user" -- unless they already exist
    user_datastore.find_or_create_role(name='admin', description='Administrator')
    user_datastore.find_or_create_role(name='moderator', description='Moderator')
    user_datastore.find_or_create_role(name='end-user', description='End user')

    # Create two Users for testing purposes -- unless they already exists.
    from datetime import datetime
    # In each case, use Flask-Security utility function to encrypt the password.
    encrypted_password = utils.encrypt_password('password')
    if not user_datastore.get_user('nayeem60151126@gmail.com'):
        user_datastore.create_user(name='Nayeem Islam',email='nayeem60151126@gmail.com', password=encrypted_password)
    if not user_datastore.get_user('islam.nayeem@outlook.com'):
        user_datastore.create_user(confirmed_at = datetime.now(), name='NoMan Nayeem',email='islam.nayeem@outlook.com', password=encrypted_password)

    # Commit any database changes; the User and Roles must exist before we can add a Role to the User
    db.session.commit()

    # Give one User has the "end-user" role, while the other has the "admin" role. (This will have no effect if the
    # Users already have these Roles.) Again, commit any database changes.
    user_datastore.add_role_to_user('nayeem60151126@gmail.com', 'end-user')
    user_datastore.add_role_to_user('islam.nayeem@outlook.com', 'admin')
    user_datastore.add_role_to_user('islam.nayeem@outlook.com', 'moderator')
    db.session.commit()


########### Test Values For Database Ends Here #########



######################## ROUTES ##############

######### Custom Routes ##########
@app.route('/')
@login_required
def index():
    if current_user.has_role('moderator'):
        return redirect('/moderator')
    if current_user.has_role('admin'):
        return redirect('/admin')
    return render_template("home.html", user=current_user.name)


@app.route('/templateindex')
@login_required
def templateindex():
    return render_template("templated.html", user=current_user.name)





a=None
filepath = None


@app.route('/upload', methods=['GET', 'POST'])
@login_required
def upload_file():
    if request.method == 'POST':
        camp_name = request.form.get('camp_name')
        file = request.files['file']
        df = pd.read_excel(file)
        if not os.path.isdir('Uploaded Files'):
            os.mkdir('Uploaded Files')
        global filepath
        filepath = os.path.join('Uploaded Files', file.filename)
        file.save(filepath)

        # print(df)
        df= df[["Number", "Text"]]
        df['Campaign_Name'] = camp_name
        df['Campaign_Time'] = str(datetime.datetime.now())
        df.to_sql('uploaded_data', con=engine, if_exists='append')
        engine.execute("SELECT * FROM uploaded_data").fetchall()
        # engine.close()

        df1= df[["Number", "Text"]]
        # Checking the length to get unusal datas dropped
        df = df1[df1['Number'].map(lambda x: len(str(x)) == 13)]
        # numbers to numeric
        df["Number"] = pd.to_numeric(df["Number"], errors='coerce')
        # Drop nulls from Numbers
        df = df.dropna(subset=['Number'])
        df = df.dropna()
        df['Number'] = df['Number'].astype('int64')
        # Store Dropped Data
        dfG = df1[~df1.index.isin(df.index)]
        # data = df
        data = df.head(5)
        # print(data)
        # # URLS Encoding
        # import urllib.parse
        # df['Text'] = df['Text'].apply(urllib.parse.quote)

        global a
        a=df
        # session["dfmain"] = splitdf.to_json()
        return render_template("templated.html", user=current_user.name, data=data.to_html(classes=["table-dark", "table-striped", "table-hover"]))


#######Campaign Start#######
loop = asyncio.new_event_loop()
asyncio.set_event_loop(loop)

# maindf = []

b=None
user_name = None
user_pass = None


@app.route('/campaign', methods=['GET', 'POST'])
@login_required
def camapign():
    print(a)
    df=a
    # URLS Encoding
    import urllib.parse
    df['Text'] = df['Text'].apply(urllib.parse.quote)

    
    ##### URL LIST #####
    urls = []
    global user_name,user_pass
    user_name = request.form.get('masking_name')
    user_pass = request.form.get('masking_pass')
    user_mask = request.form.get('masking')
    
    # session['user_mask'] = [user_mask]
    # print(df)
    for index, row in df.iterrows():
        N = row['Number']
        T = row['Text']
        url = (f"https://api.mobireach.com.bd/SendTextMessage?Username={user_name}&Password={user_pass}&From={user_mask}&To={N}&Message={T}")
        urls.append(url)
    # print('This is urls list')
    # print(urls)
    import time
    start_time = time.time()

    import asyncio
    import aiohttp
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    from aiohttp import ClientSession
    
    maindf = []

    async def hello(url, sema):
        async with ClientSession(trust_env=True) as session:
            #   maindf= []
            async with sema, session.get(url) as response:
                response = await response.read()
                # print('Response here NNNNNNNNNNNN')
                # print(response)
                root = ET.XML(response)  # Parse XML
                data = []
                for i, child in enumerate(root):
                    data.append([subchild.text for subchild in child])
                maindf.append(data)

    async def main():
        async with aiohttp.ClientSession(trust_env=True) as session:
            sema = asyncio.BoundedSemaphore(200)
            tasks = [hello(url, sema) for url in urls]
            await asyncio.gather(*tasks)

    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
    asyncio.run(main())
    # policy = asyncio.WindowsSelectorEventLoopPolicy()
    # asyncio.set_event_loop_policy(policy)
    
    maindf = pd.DataFrame(maindf)
    # print('This is maindf')
    # print(maindf)
    maindf.rename(columns={0: 'Report'}, inplace=True)
    splitdf = maindf.Report.apply(lambda x: pd.Series(str(x).split(",")))
    splitdf.rename(columns={0: 'MessageId', 1: 'Status', 2: 'StatusText', 3: 'ErrorCode', 4: 'ErrorText', 5: 'SMSCount', 6: 'CurrentCredit'}, inplace=True)
    splitdf['MessageId'] = splitdf['MessageId'].str.replace('[', '')
    splitdf['MessageId'] = splitdf['MessageId'].str.replace("'", '')
    # session["dfmain"] = splitdf.to_json()
    data = splitdf.head(10)
    global b
    b = splitdf
    #### Campaign Report ####
    flash('Campaign Completed! Generating Campaign Report', category='success')
    ##### URL LIST #####
    # return redirect(url_for('views.generatereport'))
    return render_template("templated.html", user=current_user.name, d=data.to_html(classes=["table-bordered", "table-striped", "table-hover"]))



c=None

@app.route('/generate-report', methods=['GET', 'POST'])
@login_required
def generatereport():
    df1 = pd.DataFrame(b)
    # print("This file from campign")
    # print(df1)
    murls = []
    for index, row in df1.iterrows():
        mid=row['MessageId']
        url = (f"https://api.mobireach.com.bd/GetMessageStatus?Username={user_name}&Password={user_pass}&MessageId={mid}")
        murls.append(url)
    # print(urls)
    
    reportdf = []

    async def report(url, sema):
        async with ClientSession(trust_env=True) as session:
            #   maindf= []
            async with sema, session.get(url) as response:
                response = await response.read()
                root = ET.XML(response)  # Parse XML
                data = []
                for i, child in enumerate(root):
                    data.append([subchild.text for subchild in child])
                reportdf.append(data)

    async def reportmain():
        async with aiohttp.ClientSession(trust_env=True) as session:
            sema = asyncio.BoundedSemaphore(200)
            tasks = [report(url, sema) for url in murls]
            await asyncio.gather(*tasks)
    
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
    asyncio.run(reportmain())
    reportdf = pd.DataFrame(reportdf)
    # print(maindf)
    reportdf.rename(columns={0: 'Report'}, inplace=True)
    reportsplitdf = reportdf.Report.apply(lambda x: pd.Series(str(x).split(",")))
    reportsplitdf.rename(columns={0: 'MessageId', 1: 'Status', 2: 'StatusText', 3: 'ErrorCode', 4: 'ErrorText', 5: 'SMSCount', 6: 'CurrentCredit'}, inplace=True)
    reportsplitdf['MessageId'] = reportsplitdf['MessageId'].str.replace('[', '')
    reportsplitdf['MessageId'] = reportsplitdf['MessageId'].str.replace("'", '')
    data= reportsplitdf.head(10)
    global c
    c = reportsplitdf.to_csv(index=False, header=True, sep=";")
    return render_template("reports.html",user=current_user.name, du=data.to_html(classes=["table-bordered", "table-striped", "table-hover"]))










@app.route('/download-report', methods=['GET', 'POST'])
@login_required
def downloadreport():
    # csv = session["reportsplitdf"] if "reportsplitdf" in session else ""
    csv = c
    # Create a string buffer
    buf_str = io.StringIO(csv)
    from datetime import datetime
    fname = datetime.now().strftime("%Y_%m_%d-%I_%M_%S_%p")

    # Create a bytes buffer from the string buffer
    buf_byt = io.BytesIO(buf_str.read().encode("utf-8"))
    
    # Return the CSV data as an attachment
    return send_file(buf_byt,
                     mimetype="text/csv",
                     as_attachment=True,
                     attachment_filename=f"CampaignReport{fname}.csv")










# urls.clear()



########## template Message Starts Here #########




@app.route('/template-Message', methods=['GET', 'POST'])
@login_required
def templateMessage():
    if request.method == 'POST':
        # global user_name,user_pass,user_number
        camp_name = request.form.get('camp_name')
        user_name = request.form.get('masking_name')
        user_pass = request.form.get('masking_pass')
        user_mask = request.form.get('masking')
        user_number = request.form.to_dict('number')
        user_msg = request.form.get('message')
        # file = request.files['file']
        df = pd.DataFrame(user_number, index=[0])
        from itertools import chain
        genres = df['number'].str.split(',')
        df =  (df.loc[df.index.repeat(genres.str.len())].assign(Number=list(chain.from_iterable(genres.tolist()))))
        

        
        # new_df = pd.DataFrame(df.number.str.split(',').tolist()).stack()
        # new_df= df.explode('number')

        tdf = df[["message","Number"]]
        tdf.rename({'message': 'Text', 'Number': 'Number'}, axis=1, inplace=True)

        tdf['Campaign_Name'] = camp_name
        tdf['Campaign_Time'] = str(datetime.datetime.now())
        tdf.to_sql('uploaded_data', con=engine, if_exists='append')
        engine.execute("SELECT * FROM uploaded_data").fetchall()
        print(tdf)

        new_df = df['Number']
        new_df.reset_index(drop=True, inplace=True)
        


        df=pd.DataFrame(new_df)
        
        df = df[df['Number'].map(lambda x: len(str(x)) == 13)]
        
        # numbers to numeric
        df["Number"] = pd.to_numeric(df["Number"], errors='coerce')
        df = df.dropna(subset=['Number'])
        df = df.dropna()
        df['Number'] = df['Number'].astype('int64')
        # dfG = df1[~df1.index.isin(df.index)]
        import urllib.parse
        user_msg = urllib.parse.quote(user_msg)

        # global a
        # a=df
        nurls = []
        
        # print(user_name)
        # print('Here is user name from upload function')
        T = user_msg
        for index, row in df.iterrows():
            N = row['Number']
            # T = user_msg
            url = (f"https://api.mobireach.com.bd/SendTextMessage?Username={user_name}&Password={user_pass}&From={user_mask}&To={N}&Message={T}")
            nurls.append(url)
        
        
        reportdf = []

        async def report(url, sema):
            async with ClientSession(trust_env=True) as session:
                #   maindf= []
                async with sema, session.get(url) as response:
                    response = await response.read()
                    root = ET.XML(response)  # Parse XML
                    data = []
                    for i, child in enumerate(root):
                        data.append([subchild.text for subchild in child])
                    reportdf.append(data)

        async def reportmain():
            async with aiohttp.ClientSession(trust_env=True) as session:
                sema = asyncio.BoundedSemaphore(100)
                tasks = [report(url, sema) for url in nurls]
                await asyncio.gather(*tasks)

        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
        asyncio.run(reportmain())
        
        reportdf = pd.DataFrame(reportdf)
        reportdf.rename(columns={0: 'Report'}, inplace=True)
        reportsplitdf = reportdf.Report.apply(lambda x: pd.Series(str(x).split(",")))
        reportsplitdf.rename(columns={0: 'MessageId', 1: 'Status', 2: 'StatusText', 3: 'ErrorCode', 4: 'ErrorText', 5: 'SMSCount', 6: 'CurrentCredit'}, inplace=True)
        reportsplitdf['MessageId'] = reportsplitdf['MessageId'].str.replace('[', '')
        reportsplitdf['MessageId'] = reportsplitdf['MessageId'].str.replace("'", '')
        data= reportsplitdf.head(10)
        
        return render_template("templated.html", user=current_user, dc=data.to_html(classes=["table-bordered", "table-striped", "table-hover"]))








############# Example Routes #########
@app.route('/moderator', methods=['GET', 'POST'])
@roles_accepted('moderator')
def moderator():

    users = User.query.all()
    # users = current_user.user()
    output = []

    for user in users:
        user_data = {}
        user_data['id'] = user.id
        user_data['name'] = user.name
        user_data['email'] = user.email
        user_data['password'] = user.password
        output.append(user_data)
    # print(output)



    campaign_files = []
    for value in Uploaded_data.query.group_by(Uploaded_data.Campaign_Name):
        # print(value)
        campaign_data = {}
        campaign_data['id'] = value.id
        campaign_data['name'] = value.Campaign_Name
        campaign_data['Time'] = value.Campaign_Time
        campaign_files.append(campaign_data)
    # print(campaign_data)
    
    return render_template("moderator.html", user=current_user.name, data = output, campaign_data= campaign_files)





@app.route('/downloadfile', methods=['GET', 'POST'])
@roles_accepted('moderator')
def downloadfile():
    campaign_data_name = request.form.get('campaign_data_name')
    # print('This is CAMPID')
    # print(campaign_data_name)
    # print('Came here!')
    
    data = pd.read_sql_query(''' SELECT id, Campaign_Name, Text, Number, Campaign_Time FROM uploaded_data ''',conn)
    # data = Uploaded_data.query.filter_by(Campaign_Name=campaign_data_name).all()
    # print(data)
    df = pd.DataFrame(data, columns = ['id', 'Campaign_Name', 'Text','Number','Campaign_Time'])
    df = df.loc[df['Campaign_Name'] == campaign_data_name]
    # print (df)
    # Create a string buffer
    csv = df.to_csv(index=False, header=True, sep=";")
    buf_str = io.StringIO(csv)
    from datetime import datetime
    fname = datetime.now().strftime("%Y_%m_%d-%I_%M_%S_%p")

    # Create a bytes buffer from the string buffer
    buf_byt = io.BytesIO(buf_str.read().encode("utf-8"))
    
    # Return the CSV data as an attachment
    return send_file(buf_byt,
                     mimetype="text/csv",
                     as_attachment=True,
                     attachment_filename=f"{campaign_data_name}.csv")
    






@app.route('/createuser', methods=['GET', 'POST'])
@login_required
@roles_required('moderator')
def createuser():
    return render_template("registerpage.html")







@app.route('/registeruser', methods=['GET', 'POST'])
@login_required
@roles_required('moderator')
def registeruser():
    # print('Came to register Page')
    email = request.form.get('email')
    name = request.form.get('name')
    password = request.form.get('password')
    active = False
    user = User.query.filter_by(email=email).first() # if this returns a user, then the email already exists in database

    if user: # if a user is found, we want to redirect back to signup page so user can try again
        return redirect('/moderator')

    # create a new user with the form data. Hash the password so the plaintext version isn't saved.
    new_user = User(email=email, name=name, password=password, active=active)
    
    # add the new user to the database
    db.session.add(new_user)
    user_datastore.add_role_to_user(f'{email}', 'end-user')
    db.session.commit()
    # print('Came to welcome email part')
    # send welcome email to users
    msg = Message(subject="Welcome to adaReach",
              sender=app.config.get("MAIL_USERNAME"),
              recipients=[f"<{email}>"])
    # msg.body = 'Welcome aboard  {}. Congratulations on joining our team! We look forward to sharing many successes!'.format(name)
    msg.html = render_template('security/email/welcome.html', name=name)
    mail.send(msg)
    return redirect('/login')







@app.route('/activateuser', methods=['GET', 'POST'])
# @login_required
@roles_required('moderator')
def activateuser():
    email = request.form.get('data_email')
    
    user = User.query.filter_by(email=email).first()
    user.active= True
    # user = User(active=active)
    db.session.add(user)
    db.session.commit()
    msg = Message(subject="Welcome to adaReach",
              sender=app.config.get("MAIL_USERNAME"),
              recipients=[f"<{email}>"])
    msg.body = 'Hello! Your account has been activated. Please contact adaReach Support for any query. Thanks'
    # msg.html = render_template('security/email/welcome.html', name=name)
    mail.send(msg)
    flash(f'{email} successfully activated')
    # print(f'{email} successfully activated')
    return redirect('/moderator')

@app.route('/deactivateuser', methods=['GET', 'POST'])
# @login_required
@roles_required('moderator')
def deactivateuser():
    email = request.form.get('data_email')
    user = User.query.filter_by(email=email).first()
    user.active = False
    # user.update(active = False)
    # user = User(active=active)
    db.session.add(user)
    db.session.commit()
    msg = Message(subject="Welcome to adaReach",
              sender=app.config.get("MAIL_USERNAME"),
              recipients=[f"<{email}>"])
    msg.body = 'Hello! Your account has been deactivated. Please contact adaReach Support for any query. Thanks'
    # msg.html = render_template('security/email/welcome.html', name=name)
    mail.send(msg)
    flash(f'{email} successfully deactivated')
    # print(f'{email} successfully deactivated')
    return redirect('/moderator')























if __name__ == '__main__':
    app.run(debug=True)
    # if not os.path.exists('security.db'):
    #     db.create_all()